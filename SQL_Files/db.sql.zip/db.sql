-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 06, 2005 at 08:45 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `accountID` int(11) NOT NULL auto_increment,
  `fname` varchar(30) default NULL,
  `mname` varchar(30) default NULL,
  `lname` varchar(30) default NULL,
  `username` varchar(20) default NULL,
  `password` varchar(20) default NULL,
  PRIMARY KEY  (`accountID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`accountID`, `fname`, `mname`, `lname`, `username`, `password`) VALUES
(1, 'rose', 'dela cerna', 'razon', 'admin', 'admin'),
(2, 'rose', 'mae', 'razon', 'doctor', 'doctor'),
(3, 'malou', 'p', 'baluran', 'gynestaff', 'gynestaff'),
(4, 'crystel', 'ann', 'yu', 'imgstaff', 'imgstaff'),
(5, 'malou', 'ppp', 'bal', 'pathostaff', 'pathostaff');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` int(11) NOT NULL auto_increment,
  `fname` varchar(30) default NULL,
  `mname` varchar(30) default NULL,
  `lname` varchar(30) default NULL,
  `username` varchar(20) default NULL,
  `password` varchar(20) default NULL,
  PRIMARY KEY  (`adminID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `fname`, `mname`, `lname`, `username`, `password`) VALUES
(1, 'rose', 'dela cerna', 'razon', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

CREATE TABLE `assessment` (
  `assessmentID` int(11) NOT NULL auto_increment,
  `intensity` int(11) default NULL,
  `always` tinyint(1) default NULL,
  `come_and_go` tinyint(1) default NULL,
  `make_better` varchar(50) default NULL,
  `make_worse` varchar(50) default NULL,
  `symptoms` varchar(100) default NULL,
  `sleep` tinyint(1) default NULL,
  `energy` tinyint(1) default NULL,
  `mood` tinyint(1) default NULL,
  `concentration` tinyint(1) default NULL,
  `testID` int(11) NOT NULL,
  `patientID` int(11) NOT NULL,
  PRIMARY KEY  (`assessmentID`,`testID`,`patientID`),
  KEY `testID` (`testID`,`patientID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `assessment`
--


-- --------------------------------------------------------

--
-- Table structure for table `gyne`
--

CREATE TABLE `gyne` (
  `gyneID` int(11) NOT NULL auto_increment,
  `fname` varchar(30) default NULL,
  `mname` varchar(30) default NULL,
  `lname` varchar(30) default NULL,
  `username` varchar(20) default NULL,
  `password` varchar(20) default NULL,
  PRIMARY KEY  (`gyneID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `gyne`
--

INSERT INTO `gyne` (`gyneID`, `fname`, `mname`, `lname`, `username`, `password`) VALUES
(1, 'Rose Mae Razon', 'Iligan City', '12345', 'doctor', 'doctor'),
(2, 'malou', 'ppp', 'bal', 'gynestaff', 'gynestaff');

-- --------------------------------------------------------

--
-- Table structure for table `medicalrecord`
--

CREATE TABLE `medicalrecord` (
  `recordID` int(11) NOT NULL auto_increment,
  `patientID` int(11) default NULL,
  `doctorID` int(11) default NULL,
  PRIMARY KEY  (`recordID`),
  KEY `Patient_MedicalRecord` (`patientID`),
  KEY `Doctor_MedicalRecord` (`doctorID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `medicalrecord`
--


-- --------------------------------------------------------

--
-- Table structure for table `patho`
--

CREATE TABLE `patho` (
  `pathoID` int(11) NOT NULL auto_increment,
  `fname` varchar(30) default NULL,
  `mname` varchar(30) default NULL,
  `lname` varchar(30) default NULL,
  `username` varchar(20) default NULL,
  `password` varchar(20) default NULL,
  PRIMARY KEY  (`pathoID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `patho`
--

INSERT INTO `patho` (`pathoID`, `fname`, `mname`, `lname`, `username`, `password`) VALUES
(1, 'malou', 'ppp', 'bal', 'pathostaff', 'pathostaff'),
(2, 'crystel', 'gg', 'yu', 'imgstaff', 'imgstaff');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patientID` int(11) NOT NULL auto_increment,
  `f_name` varchar(20) default NULL,
  `m_name` varchar(20) default NULL,
  `l_name` varchar(20) default NULL,
  `age` int(11) default NULL,
  `month` varchar(5) default NULL,
  `date` varchar(5) default NULL,
  `year` varchar(5) default NULL,
  `height` varchar(10) default NULL,
  `weight` varchar(10) default NULL,
  `civilstatus` varchar(10) default NULL,
  `homeadd` varchar(30) default NULL,
  `telno` varchar(10) default NULL,
  `officeadd` varchar(30) default NULL,
  `telno2` varchar(10) default NULL,
  `occupation` varchar(15) default NULL,
  `referredby` varchar(15) default NULL,
  `history` varchar(100) default NULL,
  `pertinentPE` varchar(100) default NULL,
  `findings` varchar(50) default NULL,
  PRIMARY KEY  (`patientID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patientID`, `f_name`, `m_name`, `l_name`, `age`, `month`, `date`, `year`, `height`, `weight`, `civilstatus`, `homeadd`, `telno`, `officeadd`, `telno2`, `occupation`, `referredby`, `history`, `pertinentPE`, `findings`) VALUES
(1, 'Malou', 'Pepania', 'Baluran', 61, '1', '1', '1950', '5''2"', '42', 'Married', 'Iligan City', '12345', 'Iligan City', '12345678', 'Teacher', 'None', 'Wala.', 'Wala pa.', 'Wala jud!'),
(2, '', '', '', 0, '1', '1', '1950', '', '', 'single', '', '', '', '', '', '', '', '', ''),
(3, '', '', '', 0, '1', '1', '1950', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `testresult`
--

CREATE TABLE `testresult` (
  `date` date default NULL,
  `diagnosis` varchar(50) default NULL,
  `progressNotes` varchar(100) default NULL,
  `treatment` varchar(50) default NULL,
  `testID` int(11) NOT NULL auto_increment,
  `patientID` int(11) NOT NULL,
  PRIMARY KEY  (`testID`,`patientID`),
  KEY `Patient_TestResult` (`patientID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `testresult`
--

